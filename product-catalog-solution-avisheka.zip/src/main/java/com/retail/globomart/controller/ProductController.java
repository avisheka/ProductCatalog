package com.retail.globomart.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retail.globomart.model.Products;
import com.retail.globomart.repository.IProductJpaRepository;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	IProductJpaRepository productJpaRepository;
	
	@GetMapping("/all")
	public List<Products> findAllProducts(){
		return productJpaRepository.findAll();	
	}
	
	@GetMapping("/type/{type}")
	public List<Products> findAllProductsByType(@PathVariable final String type){
		return productJpaRepository.findByType(type);		
	}
	
	@GetMapping("/id/{id}")
	public Optional<Products> findProductById(@PathVariable final Long id){
		return productJpaRepository.findById(id);
	}
	
	@PostMapping()
	public Optional<Products> addProduct(@RequestBody final Products product) {
		productJpaRepository.save(product);
		return productJpaRepository.findById(product.getId());
	}
	
	@DeleteMapping("/id/{id}")
	public void deleteProduct(@PathVariable final Long id) {
		productJpaRepository.deleteById(id);
	}
}
